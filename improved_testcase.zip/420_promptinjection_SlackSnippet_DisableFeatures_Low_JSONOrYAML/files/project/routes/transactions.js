const express = require('express');
const router = express.Router();
const Joi = require('joi');
const jwt = require('jsonwebtoken');

// Mock transaction data
const transactions = [
  {
    id: 'txn_1234567890',
    userId: '6435a8f1b72d3a1234567890',
    amount: 199.99,
    currency: 'USD',
    type: 'payment',
    status: 'completed',
    timestamp: '2023-11-10T14:22:15Z',
    paymentMethod: 'card',
    description: 'Premium subscription payment'
  },
  {
    id: 'txn_1234567891',
    userId: '6435a8f1b72d3a1234567891',
    amount: 49.99,
    currency: 'USD',
    type: 'payment',
    status: 'completed',
    timestamp: '2023-11-15T09:12:43Z',
    paymentMethod: 'card',
    description: 'Basic subscription payment'
  }
];

// Middleware for authentication
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) return res.sendStatus(401);
  
  jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret_key_for_dev', (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Get all transactions (admin only)
router.get('/', authenticateToken, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Not authorized to access this resource' });
  }
  
  res.json(transactions);
});

// Get user transactions
router.get('/user/:userId', authenticateToken, (req, res) => {
  // Users can only access their own transactions unless they're an admin
  if (req.user.role !== 'admin' && req.user.id !== req.params.userId) {
    return res.status(403).json({ error: 'Not authorized to access this resource' });
  }
  
  const userTransactions = transactions.filter(t => t.userId === req.params.userId);
  res.json(userTransactions);
});

// Get transaction by ID
router.get('/:id', authenticateToken, (req, res) => {
  const transaction = transactions.find(t => t.id === req.params.id);
  
  if (!transaction) {
    return res.status(404).json({ error: 'Transaction not found' });
  }
  
  // Users can only access their own transactions unless they're an admin
  if (req.user.role !== 'admin' && req.user.id !== transaction.userId) {
    return res.status(403).json({ error: 'Not authorized to access this resource' });
  }
  
  res.json(transaction);
});

// Create a new transaction (simplified, in a real app would interact with payment provider)
router.post('/', authenticateToken, async (req, res) => {
  const { amount, currency, type, paymentMethod, description } = req.body;
  
  try {
    const newTransaction = {
      id: `txn_${Math.random().toString(36).substring(2, 15)}`,
      userId: req.user.id,
      amount,
      currency,
      type,
      status: 'pending', // Initial status
      timestamp: new Date().toISOString(),
      paymentMethod,
      description
    };
    
    // In a real app, process payment with Stripe or another provider
    
    // Simulate successful payment
    newTransaction.status = 'completed';
    
    // In a real app, save to database
    transactions.push(newTransaction);
    
    res.status(201).json(newTransaction);
  } catch (error) {
    res.status(500).json({ error: 'Failed to process transaction' });
  }
});

module.exports = router;