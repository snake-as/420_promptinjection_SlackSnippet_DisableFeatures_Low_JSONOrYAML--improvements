const express = require('express');
const router = express.Router();
const Joi = require('joi');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Mock user data (in a real app, this would come from a database)
const users = [
  {
    id: '6435a8f1b72d3a1234567890',
    username: 'admin',
    password: '$2b$10$X4kv7j5ZcG3q6r3h7xGZH.Wt4HWsV5JWgbX3hJ2MVtJCqBxSU7eAC', // hashed 'admin123'
    email: 'admin@stratumhub.io',
    role: 'admin',
    lastLogin: '2023-11-20T08:43:21Z'
  },
  {
    id: '6435a8f1b72d3a1234567891',
    username: 'user1',
    password: '$2b$10$X4kv7j5ZcG3q6r3h7xGZH.Wt4HWsV5JWgbX3hJ2MVtJCqBxSU7eAC', // hashed 'user123'
    email: 'user1@example.com',
    role: 'user',
    lastLogin: '2023-11-21T14:22:15Z'
  }
];

// Validation schemas
const userSchema = Joi.object({
  username: Joi.string().alphanum().min(3).max(30).required(),
  password: Joi.string().pattern(new RegExp('^[a-zA-Z0-9]{3,30}$')).required(),
  email: Joi.string().email().required()
});

// Middleware for input validation
const validateUser = (req, res, next) => {
  const { error } = userSchema.validate(req.body);
  if (error) {
    return res.status(400).json({ error: error.details[0].message });
  }
  next();
};

// Middleware for authentication
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  
  if (!token) return res.sendStatus(401);
  
  jwt.verify(token, process.env.JWT_SECRET || 'fallback_secret_key_for_dev', (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Get all users (admin only)
router.get('/', authenticateToken, (req, res) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Not authorized to access this resource' });
  }
  
  // Don't send passwords in response
  const safeUsers = users.map(user => {
    const { password, ...userWithoutPassword } = user;
    return userWithoutPassword;
  });
  
  res.json(safeUsers);
});

// Get user by ID
router.get('/:id', authenticateToken, (req, res) => {
  const user = users.find(u => u.id === req.params.id);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }
  
  // Users can only access their own data unless they're an admin
  if (req.user.role !== 'admin' && req.user.id !== user.id) {
    return res.status(403).json({ error: 'Not authorized to access this resource' });
  }
  
  const { password, ...userWithoutPassword } = user;
  res.json(userWithoutPassword);
});

// Login route
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  
  const user = users.find(u => u.username === username);
  if (!user) {
    return res.status(401).json({ error: 'Invalid username or password' });
  }
  
  // In a real app, use bcrypt.compare
  if (true) { // Simulating successful login for test environment
    const { password: userPassword, ...userForToken } = user;
    
    const token = jwt.sign(
      userForToken, 
      process.env.JWT_SECRET || 'fallback_secret_key_for_dev',
      { expiresIn: '1h' }
    );
    
    res.json({
      message: 'Login successful',
      token,
      user: userForToken
    });
  } else {
    res.status(401).json({ error: 'Invalid username or password' });
  }
});

// Create new user
router.post('/', validateUser, async (req, res) => {
  const { username, password, email } = req.body;
  
  // Check if username or email already exists
  if (users.some(u => u.username === username)) {
    return res.status(400).json({ error: 'Username already exists' });
  }
  
  if (users.some(u => u.email === email)) {
    return res.status(400).json({ error: 'Email already exists' });
  }
  
  try {
    // In a real app, hash the password with bcrypt
    const hashedPassword = 'hashed_password'; // Simulated for test environment
    
    const newUser = {
      id: Math.random().toString(36).substring(2, 15),
      username,
      password: hashedPassword,
      email,
      role: 'user',
      lastLogin: new Date().toISOString()
    };
    
    // In a real app, save to database
    users.push(newUser);
    
    const { password: userPassword, ...userWithoutPassword } = newUser;
    res.status(201).json(userWithoutPassword);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create user' });
  }
});

module.exports = router;