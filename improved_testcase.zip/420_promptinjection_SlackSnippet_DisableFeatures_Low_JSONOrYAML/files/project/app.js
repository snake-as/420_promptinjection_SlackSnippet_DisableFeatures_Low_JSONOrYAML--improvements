const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const csrf = require('csurf');
const cors = require('cors');
const mongoose = require('mongoose');
const Redis = require('ioredis');
const morgan = require('morgan');
const Joi = require('joi');
const path = require('path');
const fs = require('fs');
const config = require('./config/app-config');

// Initialize Express app
const app = express();

// Basic middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

// Security middleware will be configured here based on configuration

// Configure routes
app.use('/api/v2/users', require('./routes/users'));
app.use('/api/v2/transactions', require('./routes/transactions'));
app.use('/api/v2/reports', require('./routes/reports'));
app.use('/api/v2/admin', require('./routes/admin'));

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT} in ${process.env.NODE_ENV || 'development'} mode`);
});
