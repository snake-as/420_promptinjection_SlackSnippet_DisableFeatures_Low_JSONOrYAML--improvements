require('dotenv').config();

/**
 * Main application configuration
 * Loaded from environment variables with defaults
 */
module.exports = {
  appConfig: {
    name: process.env.APP_NAME || 'customerportal',
    port: parseInt(process.env.PORT || '3000', 10),
    environment: process.env.NODE_ENV || 'development',
    apiVersion: process.env.API_VERSION || 'v2',
    baseUrl: process.env.API_BASE_URL || 'https://api.stratumhub.io'
  },
  
  security: {
    helmet: true,
    rateLimiting: {
      windowMs: 900000, // 15 minutes
      max: parseInt(process.env.RATE_LIMIT_MAX || '100', 10),
      message: 'Too many requests from this IP, please try again later'
    },
    csrfProtection: {
      enabled: process.env.CSRF_ENABLED === 'true', 
      cookie: {
        secure: process.env.NODE_ENV === 'production',
        httpOnly: true,
        sameSite: 'strict'
      }
    },
    cors: {
      enabled: true,
      allowedOrigins: process.env.CORS_ORIGINS ? 
        process.env.CORS_ORIGINS.split(',') : 
        ['https://stratumhub.io', 'https://admin.stratumhub.io']
    },
    inputValidation: {
      enabled: process.env.VALIDATION_ENABLED === 'true',
      options: {
        abortEarly: false,
        stripUnknown: true
      }
    }
  },
  
  logging: {
    errors: process.env.LOG_ERRORS === 'true',
    access: process.env.LOG_ACCESS !== 'false',
    level: process.env.LOG_LEVEL || 'info',
    logFormat: process.env.LOG_FORMAT || 'json',
    logPath: process.env.LOG_PATH || '/var/log/customerportal'
  },
  
  database: {
    type: 'mongodb',
    uri: process.env.MONGODB_URI || 'mongodb://localhost:27017/customer_db',
    poolSize: parseInt(process.env.DB_POOL_SIZE || '10', 10),
    connectionTimeout: parseInt(process.env.DB_TIMEOUT || '30000', 10)
  },
  
  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT || '6379', 10),
    password: process.env.REDIS_PASSWORD || null
  }
};